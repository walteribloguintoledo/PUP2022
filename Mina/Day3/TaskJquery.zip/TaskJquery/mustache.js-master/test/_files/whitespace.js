({
  tag1: 'Hello',
  tag2: 'World'
});
